==========
My Project
==========


Features
########

Place your plugin features list.

Installation
############

Open edX devstack
*****************

- Clone this repo in the src folder of your devstack.
- Open a new Lms/Devstack shell.
- Install the plugin as follows: pip install -e /path/to/your/src/folder
- Restart Lms/Studio services.

Usage
#####

Include a usage description for your plugin.

Contributing
############

Add your contribution policy. (If required)
