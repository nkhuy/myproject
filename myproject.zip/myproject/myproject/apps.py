"""
App configuration for myproject.
"""

from __future__ import unicode_literals

from django.apps import AppConfig


class MyProjectConfigConfig(AppConfig):
    """
    My Project configuration.
    """
    name = 'myproject'
    verbose_name = 'My Project'

    plugin_app = {
        'url_config': {
            'lms.djangoapp': {
                'namespace': 'myproject',
                'regex': r'^myproject/',
                'relative_path': 'urls',
            },
            'cms.djangoapp': {
                'namespace': 'myproject',
                'regex': r'^myproject/',
                'relative_path': 'urls',
            }
        },
        'settings_config': {
            'lms.djangoapp': {
                'common': {'relative_path': 'settings.common'},
                'test': {'relative_path': 'settings.test'},
                'aws': {'relative_path': 'settings.aws'},
                'production': {'relative_path': 'settings.production'},
            },
            'cms.djangoapp': {
                'common': {'relative_path': 'settings.common'},
                'test': {'relative_path': 'settings.test'},
                'aws': {'relative_path': 'settings.aws'},
                'production': {'relative_path': 'settings.production'},
            },
        }
    }
