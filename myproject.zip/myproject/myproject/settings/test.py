"""
Test Django settings for myproject project.
"""

from __future__ import unicode_literals

from .common import *  # pylint: disable=wildcard-import
